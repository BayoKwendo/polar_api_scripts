<?php

//echo "PeakInsight confirmation url"; die();

header("Content-Type:application/json");
date_default_timezone_set("Africa/Nairobi");

include_once('QueryManager.php');

$request = file_get_contents('php://input');

define("LOG_FILE", "/var/log/mpesa/mifone_confirm.log");

#define("LOG_FILE", "C://xampp//htdocs//logs//mifone_confirm.log");

error_log("\nINFO " . date("Y/m/d H:i:s"). "$request\n", 3, LOG_FILE);

$trx = json_decode($request, true);


logMpesaTransaction($trx);

sendSMSResponse($trx);

<?php
header("Content-Type:application/json");
date_default_timezone_set("Africa/Nairobi");

$request = file_get_contents('php://input');

define("LOG_FILE", "/var/log/mpesa/mifone_validate.log");

#define("LOG_FILE", "C://xampp//htdocs//logs//mifone_validate.log");

//record the request
error_log("\nINFO " . date("Y/m/d H:i:s"). "$request\n", 3, LOG_FILE);

$trx = json_decode($request, true);

#$transactiontype = $trx['TransactionType'];
$transid = $trx['TransID'];
$transtime = $trx['TransTime'];
$transamount = $trx['TransAmount'];
$businessshortcode = $trx['BusinessShortCode'];
$accountNo = $trx['BillRefNumber'];
$invoiceno = $trx['InvoiceNumber'];
$thirdpartytrx = $trx['ThirdPartyTransID'];
$msisdn = $trx['MSISDN'];
$orgaccountbalance = $trx['OrgAccountBalance'];
$firstname = 'ddffj';
$middlename = $trx['MiddleName'];
$lastname = $trx['LastName'];


    //$responseMsg = fetchResponse($arr);


$data = array(

	"filter_value" => $accountNo
);

$options = array(
	'http' => array(
		'method'  => 'POST',
		'content' => json_encode( $data ),
		'header'=>  "Content-Type: application/json\r\n" .
		"Accept: application/json\r\n"
	)
);

$context  = stream_context_create( $options );
$result = file_get_contents( "https://www.peakbooks.biz:2005/getpayments", false, $context );
$response = json_decode( $result );


$data = json_decode($result);

if($data->status == true){
	$response = '{"ResultCode": 0,"ResultDesc": "Accepted"}';
}else{

	$firstname = $trx['FirstName'];
	$transid = $trx['TransID'];
	$msisdn = $trx['MSISDN'];
	$base64 = base64_encode("polaragencies:Shamari0852");

    //$responseMsg = fetchResponse($arr);
	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "http://107.20.199.106/restapi/sms/1/text/single",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => '{

			"from": "POLAR_MGT",
			"to": "'.$msisdn.'",
			"text": "Dear '.$firstname.', your payment transaction could not proceed due to mismatch of your account no details with ours.\n\nPlease check your ID/Passport Number and try again\n\n"
		}',


		CURLOPT_HTTPHEADER => array(
			"content-type: application/json",
			"Authorization: Basic $base64"

		),
	));
	$response = curl_exec($curl);
	$err = curl_error($curl);
	curl_close($curl);
	if ($err) {

		$response = '{"ResultCode": 1,"ResultDesc": "Rejected"}';

	} else {
		$response = '{"ResultCode": 1,"ResultDesc": "Rejected"}';
	}
}

echo $response;


<?php

//Query manager

function logMpesaTransaction($trx){

	$transactiontype = $trx['TransactionType'];
	$transid = $trx['TransID'];
	$transtime = $trx['TransTime'];
	$transamount = $trx['TransAmount'];
	$businessshortcode = $trx['BusinessShortCode'];
	$accountNo = $trx['BillRefNumber'];
	$invoiceno = $trx['InvoiceNumber'];
	$thirdpartytrx = $trx['ThirdPartyTransID'];
	$msisdn = $trx['MSISDN'];
	$orgaccountbalance = $trx['OrgAccountBalance'];
	$firstname = $trx['FirstName'];
	$middlename = $trx['MiddleName'];
	$lastname = $trx['LastName'];


   //$responseMsg = fetchResponse($arr);


    $data = array(

        "filter_value" => $accountNo,

        "mpesa_no" => $msisdn,
        "amount" => $transamount,
        
        "reference_number" => $transid
    );

    $options = array(
        'http' => array(
            'method'  => 'POST',
            'content' => json_encode( $data ),
            'header'=>  "Content-Type: application/json\r\n" .
            "Accept: application/json\r\n"
        )
    );

    $context  = stream_context_create( $options );
    $result = file_get_contents( "https://www.peakbooks.biz:2005/mpesapayments", false, $context );
    $respons = json_decode( $result );


    echo $result; 


    
}


function sendSMSResponse($trx) {

    $firstname = $trx['FirstName'];
    $transid = $trx['TransID'];

    $msisdn = $trx['MSISDN'];

    //$responseMsg = fetchResponse($arr)

    $base64 = base64_encode("polaragencies:Shamari0852");

    $params = array ("from" => 'POLAR_MGT', "to" => $msisdn, "text" => "Dear $firstname,\n\nThis to confirm that your  payment with reference $transid is well received.\n\n" );

    $query = http_build_query ($params);

       // Create Http context details
    $contextData = array ( 
        'method' => 'POST',
        'header' => "Authorization: Basic $base64\r\n".
        "Content-Length: ".strlen($query)."\r\n",
        'content'=> $query );

         // Create context resource for our request
    $context = stream_context_create (array ( 'http' => $contextData ));

// Read page rendered as result of your POST request
    $result =  file_get_contents (
              'http://107.20.199.106/restapi/sms/1/text/single',  // page url
              false,
              $context);

    if ($result) {

        $response = '{"ResultCode": 1,"ResultDesc": "Rejected"}';

    } else {
        $response = '{"ResultCode": 1,"ResultDesc": "Rejected"}';
    }   

    $firstname = $trx['FirstName'];
    $transid = $trx['TransID'];
    $msisdn = $trx['MSISDN'];
    $base64 = base64_encode("polaragencies:Shamari0852");

    //$responseMsg = fetchResponse($arr);
    
}

<?php 
$con = mysqli_connect("157.230.229.119:10330","root","VF3ax6geGdfg32dufgf8","peakbooks");

if (!$con) {
  die('Could not connect: ' . mysqli_error());
}


